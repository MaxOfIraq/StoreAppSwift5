//
//  TableTableViewCell.swift
//  CollectionView
//
//  Created by Ahmed Salah on 28/12/2020.
//

import UIKit

class TableTableViewCell: UITableViewCell {

    @IBOutlet weak var imageCell: UIImageView!
    @IBOutlet weak var titleLabel01: UILabel!
    @IBOutlet weak var textLabel02: UILabel!
    @IBOutlet weak var Aroo: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.imageCell.layer.cornerRadius = self.imageCell.frame.width/4.0
        self.imageCell.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
