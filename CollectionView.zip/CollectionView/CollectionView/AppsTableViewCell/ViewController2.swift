//
//  ViewController2.swift
//  CollectionView
//
//  Created by Ahmed Salah on 28/12/2020.
//

import UIKit

class ViewController2: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    let refteash = UIRefreshControl()
    
    // Link install
    
    let titlesF = [("Instagram ++"),("Cercube"),("Twitter ++"),("Watusi"),("Picsart ++"),("Facebook ++"),("Cute Cut pro"),("GBA4iOS"),("PPSSPP"),("Delta")]
    
    
    let desF = [("Duplicate"), ("Delete the original"), ("Duplicate"), ("Delete the original"), ("Delete the original"), ("Delete the original"),("Delete the original"), ("Delete the original"), ("Delete the original"), ("Delete the original")]
    
    
    let imagesF = [UIImage(named: "instagram"), UIImage(named: "youtube"), UIImage(named: "twitter"), UIImage(named: "whatsapp"), UIImage(named: "picsart"), UIImage(named: "facebook"), UIImage(named: "cut"), UIImage(named: "GBA4IOS"), UIImage(named: "ppsspp"), UIImage(named: "Delta")]
    
    //    itms-services://?action=download-manifest&url=

    let urls = ["#","#","#","#","#","#","#","#","#","#"]
    
    

    

    // Link Coding Cell
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        refteash.tintColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        refteash.addTarget(self, action: #selector(getData), for: .valueChanged)
        tableView.addSubview(refteash )
    }
    
    
    @objc func getData(){
        refteash.endRefreshing()
        tableView.reloadData()
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }

    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titlesF.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath as IndexPath) as! TableTableViewCell
        cell.imageCell.image = self.imagesF[indexPath .row]
        cell.titleLabel01.text = self.titlesF[indexPath .row]
        cell.textLabel02.text = self.desF[indexPath .row]
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let url = URL(string: urls[indexPath.row]) {
            UIApplication.shared.open(url)
        }
    }


}

