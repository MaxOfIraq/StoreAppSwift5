//
//  CollectionViewCell.swift
//  CollectionView
//
//  Created by Ahmed Salah on 28/12/2020.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var laImage: UIImageView!
    @IBOutlet weak var laName: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()

        
        // Image cornerRadius
        
        self.laImage.layer.cornerRadius = self.laImage.frame.width/4.0
        self.laImage.clipsToBounds = true
    }
}
