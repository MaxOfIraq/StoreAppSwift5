//
//  ViewController.swift
//  CollectionView
//
//  Created by Ahmed Salah on 28/12/2020.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {

    

    @IBOutlet weak var CollectionView: UICollectionView!
    
    
    let laName = ["instaDlEasy","TwittDLeasy","WhatsPad","Telegram2","Muslim Pro","YoDleasy"]
    
    
    
    let laImage = [UIImage(named: "instagram"), UIImage(named: "twitter"), UIImage(named: "whatsapp"), UIImage(named: "telegram"), UIImage(named: "muslimpro"), UIImage(named: "yo")]
    
    
    
    let urls = ["#","#","#","#","#","#"]
    
    
        
    override func viewDidLoad() {
        super.viewDidLoad()
        CollectionView.delegate = self
        CollectionView.dataSource = self
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return laName.count
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = CollectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath as IndexPath) as! CollectionViewCell
        cell.laImage.image = self.laImage[indexPath .row]
        cell.laName.text = self.laName[indexPath .row]
        
        // Corner Radius
        cell.layer.cornerRadius = 10
        cell.layer.masksToBounds = true

        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let url = URL(string: urls[indexPath.row]) {
            UIApplication.shared.open(url)
        }
    }
    

}
