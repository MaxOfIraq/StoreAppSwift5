//
//  ViewController3.swift
//  CollectionView
//
//  Created by Ahmed Salah on 29/12/2020.
//

import UIKit

class ViewController3: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var proTableView: UITableView!
    
    
    let refreash = UIRefreshControl()
    
    
    
    let namVC = [("Instagram ++"),("Cercube"),("Twitter ++"),("Watusi"),("Picsart ++"),("Facebook ++"),("Cute Cut pro"),("GBA4iOS"),("PPSSPP"),("Delta")]
    
    
    
    
    
    
    let desVC = [("Duplicate"), ("Delete the original"), ("Duplicate"), ("Delete the original"), ("Delete the original"), ("Delete the original"),("Delete the original"), ("Delete the original"), ("Delete the original"), ("Delete the original")]
    
    
    
    
    
    
    
    
    let imageVC = [UIImage(named: "instagram"), UIImage(named: "youtube"), UIImage(named: "twitter"), UIImage(named: "whatsapp"), UIImage(named: "picsart"), UIImage(named: "facebook"), UIImage(named: "cut"), UIImage(named: "GBA4IOS"), UIImage(named: "ppsspp"), UIImage(named: "Delta")]
    
    //    itms-services://?action=download-manifest&url=

    
    
    
    
    
    
    let urls = ["#","#","#","#","#","#","#","#","#","#"]
    
    

    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        proTableView.dataSource = self
        proTableView.delegate = self
        
        refreash.tintColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        refreash.addTarget(self, action: #selector(getData), for: .valueChanged)
        proTableView.addSubview(refreash)
        
    }
    
    
    @objc func getData(){
        refreash.endRefreshing()
        proTableView.reloadData()
    }
    
    
    

    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }

    
    

    // tag in section
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return namVC.count
    }
    
    
    
    
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "cell3", for: indexPath as IndexPath) as! TableViewCell
        cell.imageVC.image = self.imageVC[indexPath .row]
        cell.namVC.text = self.namVC[indexPath .row]
        cell.desVC.text = self.desVC[indexPath .row]
        return cell
    }
    
    
    
    

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let url = URL(string: urls[indexPath.row]) {
            UIApplication.shared.open(url)
        }
    }


}




























//@IBAction func ipaLibrary(_ sender: Any)
//{
//    guard let url = URL(string: "https://ipa-library.netlify.app/") else { return }
//            UIApplication.shared.open(url)
//}
//@IBAction func TweakApps(_ sender: Any)
//{
//    guard let url = URL(string: "https://c2-max.netlify.app/") else { return }
//            UIApplication.shared.open(url)
//}
