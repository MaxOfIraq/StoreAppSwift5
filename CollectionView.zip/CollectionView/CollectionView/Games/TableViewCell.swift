//
//  TableViewCell.swift
//  CollectionView
//
//  Created by Ahmed Salah on 04/01/2021.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var imageVC: UIImageView!
    @IBOutlet weak var namVC: UILabel!
    @IBOutlet weak var desVC: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.imageVC.layer.cornerRadius = self.imageVC.frame.width/4.0
        self.imageVC.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
