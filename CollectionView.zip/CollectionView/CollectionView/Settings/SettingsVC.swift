//
//  SettingsVC.swift
//  CollectionView
//
//  Created by Ahmed Salah on 10/01/2021.
//

import UIKit

class SettingsVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    

    @IBOutlet weak var SettingTable: UITableView!
    let setting = ["Twitter", "Facebook","Instagram","YouTube","Buy me a coffee"]
    
    
    let LimgX = [UIImage(named: "TwitterX"), UIImage(named: "FacebookX"),UIImage(named: "InstagramX"), UIImage(named: "YouTubeX"), UIImage(named: "PayPalX")]
    
    
    let urls = ["#","#","#","#","#"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        SettingTable.delegate = self
        SettingTable.dataSource = self
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return setting.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = SettingTable.dequeueReusableCell(withIdentifier: "cellX", for:   indexPath as IndexPath) as! SettingsTableView
        
        cell.LnameX.text = self.setting[indexPath.row]
        cell.LimgX.image = self.LimgX[indexPath .row]
        return cell
    }


    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let url = URL(string: urls[indexPath.row]) {
            UIApplication.shared.open(url)
        }
    }

}
