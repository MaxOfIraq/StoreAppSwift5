//
//  SettingsTableView.swift
//  CollectionView
//
//  Created by Ahmed Salah on 10/01/2021.
//

import UIKit

class SettingsTableView: UITableViewCell {

    @IBOutlet weak var LnameX: UILabel!
    @IBOutlet weak var LimgX: UIImageView!
    @IBOutlet weak var Arow: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.LimgX.layer.cornerRadius = self.LimgX.frame.width/4.0
        self.LimgX.clipsToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
