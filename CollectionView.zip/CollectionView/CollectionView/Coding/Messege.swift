//
//  Messege.swift
//  CollectionView
//
//  Created by Ahmed Salah on 29/12/2020.
//

import UIKit

class Messege: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Messege(_ sender: Any)
    {
        dismiss(animated: false, completion: nil)
    }
    
   

}
