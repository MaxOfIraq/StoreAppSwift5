//
//  Button.swift
//  CollectionView
//
//  Created by Ahmed Salah on 29/12/2020.
//

import UIKit
class Button : UIButton{
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.cornerRadius = 10
        self.layer.shadowColor = UIColor.black.cgColor
        self.layer.shadowOpacity = 1
        self.layer.shadowOffset = .zero
        self.layer.shadowRadius = 10
    }
}

