//
//  Button2.swift
//  CollectionView
//
//  Created by Ahmed Salah on 29/12/2020.
//

import UIKit
class Button2 : UIButton{
    override func awakeFromNib() {
        super.awakeFromNib()
        self.layer.cornerRadius = 10
    }
}
